package com.aggeri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeoQuiz1Application {

	public static void main(String[] args) {
		SpringApplication.run(GeoQuiz1Application.class, args);
	}

}
