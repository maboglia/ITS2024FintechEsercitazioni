package com.aggeri.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Utente {
	
	@Id
	private String userName;
	
	private String pass;
	private int punteggio;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public int getPunteggio() {
		return punteggio;
	}
	public void setPunteggio(int punteggio) {
		this.punteggio = punteggio;
	}

}