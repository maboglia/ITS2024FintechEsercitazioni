package com.aggeri.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aggeri.entities.Paese;

public interface PaeseDAO extends JpaRepository<Paese, Integer> {
	
	List<Paese> findByRegione(String regione);

}
