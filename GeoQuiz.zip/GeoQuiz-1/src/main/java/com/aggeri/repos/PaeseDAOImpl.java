package com.aggeri.repos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.aggeri.db.Connessione;

public class PaeseDAOImpl {
	
	private Connessione miaConn = new Connessione();
	private Statement istruzioniDB;
	private PreparedStatement istruzioniDBPreparate;
	private ResultSet risultatiQuery;
	
	private final String COUNTRIES_LENGTH = "SELECT COUNT(id) FROM its_2024.countriesv2";
	
	public int getMax() throws SQLException {
		
		int count = 0;

        try (Statement statement = miaConn.getConn().createStatement();
             ResultSet resultSet = statement.executeQuery(COUNTRIES_LENGTH)) {

            if (resultSet.next()) {
                count = resultSet.getInt(1); // Get the count from the first column
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception properly in a real-world application
        }
        
        System.out.println(count);

        return count;
    }
}