package com.aggeri.repos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aggeri.entities.Utente;

public interface UtenteDAO extends JpaRepository<Utente, String> {
	
	Optional<Utente> findByUserName(String userName);

}