package com.aggeri.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aggeri.entities.Utente;
import com.aggeri.services.UtenteService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UtenteMVC {

	@Autowired
	private UtenteService utenteService;

	@RequestMapping("/login")
	public String showLoginPage() {
		return "login";
	}
	
	@RequestMapping("/login-home")
	public String showLoginPageHome() {
		return "login-home";
	}

	@RequestMapping("/login-flag")
	public String showLoginPageBandiera() {
		return "login-bandiera";
	}

	@RequestMapping("/login-profile")
	public String showLoginPageProfilo() {
		return "login-profilo";
	}
	
	@RequestMapping("/login-memory")
	public String showLoginPageMemory() {
		return "login-memory";
	}

	@PostMapping("/login")
	public String loginUser(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		if (utenteService.authenticate(username, password)) {
			Utente loggedUser = utenteService.getUtenteById(username);
			session.setAttribute("utente", loggedUser); // Store the user in the session
			return "redirect:/paese-random";
		} else {
			model.addAttribute("message", "Credenziali non valide. Si prega di riprovare.");
			return "login";
		}
	}
	
	@PostMapping("/login-home")
	public String loginUserHome(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		if (utenteService.authenticate(username, password)) {
			Utente loggedUser = utenteService.getUtenteById(username);
			session.setAttribute("utente", loggedUser); // Store the user in the session
			return "redirect:/home";
		} else {
			model.addAttribute("message", "Credenziali non valide. Si prega di riprovare.");
			return "login-home";
		}
	}

	@PostMapping("/login-bandiera")
	public String loginUserBandiera(@RequestParam("username") String username,
			@RequestParam("password") String password, Model model, HttpSession session) {
		if (utenteService.authenticate(username, password)) {
			Utente loggedUser = utenteService.getUtenteById(username);
			session.setAttribute("utente", loggedUser); // Store the user in the session
			return "redirect:/bandiera-random";
		} else {
			model.addAttribute("message", "Credenziali non valide. Si prega di riprovare.");
			return "login-bandiera";
		}
	}

	@PostMapping("/login-profilo")
	public String loginUserProfilo(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		if (utenteService.authenticate(username, password)) {
			Utente loggedUser = utenteService.getUtenteById(username);
			session.setAttribute("utente", loggedUser); // Store the user in the session
			return "redirect:/profilo";
		} else {
			model.addAttribute("message", "Credenziali non valide. Si prega di riprovare.");
			return "login-profilo";
		}
	}
	
	@PostMapping("/login-memory")
	public String loginUserMemory(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		if (utenteService.authenticate(username, password)) {
			Utente loggedUser = utenteService.getUtenteById(username);
			session.setAttribute("utente", loggedUser); // Store the user in the session
			return "redirect:/memory-quiz";
		} else {
			model.addAttribute("message", "Credenziali non valide. Si prega di riprovare.");
			return "login-memory";
		}
	}

	@RequestMapping("/register")
	public String showRegisterPage() {
		return "register";
	}
	
	@RequestMapping("/register-home")
	public String showRegisterHome() {
		return "register-home";
	}

	@RequestMapping("/register-bandiera")
	public String showRegisterPagebandiera() {
		return "register-bandiera";
	}
	
	@RequestMapping("/register-memory")
	public String showRegisterPageMemory() {
		return "register-memory";
	}

	@PostMapping("/register")
	public String registerUser(@RequestParam("username") String username, @RequestParam("password") String password,
			@RequestParam("password2") String password2, Model model) {
		if (!password.equals(password2)) {
			model.addAttribute("message", "Le password non coincidono. Si prega di riprovare.");
			return "register";
		}

		if (utenteService.getUtenteById(username) != null) {
			model.addAttribute("message", "Nome utente già esistente. Scegliere un altro nome utente.");
			return "register";
		}

		Utente newUser = new Utente();
		newUser.setUserName(username);
		newUser.setPass(password);
		utenteService.register(newUser);

		model.addAttribute("message", "Registrazione avvenuta con successo! Effettua il login.");
		return "login";
	}
	
	@PostMapping("/register-home")
	public String registerUserHome(@RequestParam("username") String username, @RequestParam("password") String password,
			@RequestParam("password2") String password2, Model model) {
		if (!password.equals(password2)) {
			model.addAttribute("message", "Le password non coincidono. Si prega di riprovare.");
			return "register-home";
		}

		if (utenteService.getUtenteById(username) != null) {
			model.addAttribute("message", "Nome utente già esistente. Scegliere un altro nome utente.");
			return "register-home";
		}

		Utente newUser = new Utente();
		newUser.setUserName(username);
		newUser.setPass(password);
		utenteService.register(newUser);

		model.addAttribute("message", "Registrazione avvenuta con successo! Effettua il login.");
		return "login-home";
	}

	@PostMapping("/register-bandiera")
	public String registerUserBandiera(@RequestParam("username") String username,
			@RequestParam("password") String password, @RequestParam("password2") String password2, Model model) {
		if (!password.equals(password2)) {
			model.addAttribute("message", "Le password non coincidono. Si prega di riprovare.");
			return "register-bandiera";
		}

		if (utenteService.getUtenteById(username) != null) {
			model.addAttribute("message", "Nome utente già esistente. Scegliere un altro nome utente.");
			return "register-bandiera";
		}

		Utente newUser = new Utente();
		newUser.setUserName(username);
		newUser.setPass(password);
		utenteService.register(newUser);

		model.addAttribute("message", "Registrazione avvenuta con successo! Effettua il login.");
		return "login-bandiera";
	}
	
	@PostMapping("/register-memory")
	public String registerUserMemory(@RequestParam("username") String username,
			@RequestParam("password") String password, @RequestParam("password2") String password2, Model model) {
		if (!password.equals(password2)) {
			model.addAttribute("message", "Le password non coincidono. Si prega di riprovare.");
			return "register-memory";
		}

		if (utenteService.getUtenteById(username) != null) {
			model.addAttribute("message", "Nome utente già esistente. Scegliere un altro nome utente.");
			return "register-memory";
		}

		Utente newUser = new Utente();
		newUser.setUserName(username);
		newUser.setPass(password);
		utenteService.register(newUser);

		model.addAttribute("message", "Registrazione avvenuta con successo! Effettua il login.");
		return "login-memory";
	}

	@PostMapping("/update-score")
	@ResponseBody
	public ResponseEntity<Map<String, Object>> updateScore(@RequestBody Map<String, Integer> payload, HttpSession session) {
	    Utente utente = (Utente) session.getAttribute("utente");
	    if (utente != null) {
	        int newScore = payload.get("score");
	        utente.setPunteggio(newScore);
	        // Save the updated user to the database
	        utenteService.updateUtente(utente);
	        session.setAttribute("utente", utente); // Update session attribute
	        return ResponseEntity.ok(Map.of("success", true));
	    }
	    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("success", false));
	}

	@GetMapping("/profilo")
	public String getProfilo(Model m, HttpSession session) {
	    Utente utente = (Utente) session.getAttribute("utente");
	    if (utente == null) {
	        return "redirect:/login-profile";
	    }
	    
	    String message = hasEnoughPoints(utente) ? "" : "Non hai abbastanza punti!! Devi avere almeno 20 punti.";
	    m.addAttribute("message", message);
	    m.addAttribute("utente", utente);
	    
	    return "profilo";
	}

	private boolean hasEnoughPoints(Utente utente) {
	    return utente.getPunteggio() >= 20;
	}
	
	@RequestMapping("/leaderboard")
	public String showLeaderboard() {
		return "leaderboard";
	}

}