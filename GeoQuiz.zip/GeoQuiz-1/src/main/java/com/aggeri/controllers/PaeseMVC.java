package com.aggeri.controllers;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aggeri.entities.Paese;
import com.aggeri.entities.Utente;
import com.aggeri.services.PaeseService;

import jakarta.servlet.http.HttpSession;

@Controller
public class PaeseMVC {
	
	@Autowired
	private PaeseService service;
	
	@GetMapping("")
	String welcome() {
		return "welcome";
	}
	
	@GetMapping("welcome")
	String welcome2() {
		return "welcome";
	}
	
	@GetMapping("home")
	String home() {
		return "index";
	}
	
	@GetMapping("capital")
	String capital() {
		return "capital";
	}
	
	@GetMapping("flag")
	String flag() {
		return "flag";
	}
	
	@GetMapping("impara")
	String impara() {
		return "impara";
	}
	
	@GetMapping("paesi-mondo")
	String viewWorldCountries() {
		return "paesi-mondo";
	}
	
	@GetMapping("/memory-quiz")
	public String memoryQuiz(Model model, HttpSession session, RedirectAttributes redirectAttributes) {
	    Utente utente = (Utente) session.getAttribute("utente"); // Retrieve the user from the session
	    
	    if (utente == null) {
	        return "redirect:/login-memory";
	    }
	    
	    if (!hasEnoughPoints(utente)) {
	        redirectAttributes.addFlashAttribute("message", "Non hai abbastanza punti per giocare!! Devi prima raggiungere 20 punti totali.");
	        return "redirect:/home";
	    }
	    
	    model.addAttribute("utente", utente); // Pass the user to the view
	    return "memory-quiz";
	}

	private boolean hasEnoughPoints(Utente utente) {
	    return utente.getPunteggio() >= 20;
	}
	
	@PostMapping("/clear-alert-message")
	@ResponseBody
	public void clearAlertMessage(HttpSession session) {
	    session.removeAttribute("alertMessage");
	}
	
	@GetMapping("paese")
	public String getPaese(Model m) {
		m.addAttribute("elencopaesi", service.getPaese());
		return "elencoPaesi";
	}
	
    @GetMapping("/paese-popolazione")
    public String getPaesePopolazione(Model m) {
        List<Paese> paesiList = service.getPaese()
                                       .stream()
                                       .sorted(Comparator.comparing(Paese::getPopolazione).reversed()) // Sort by population in descending order
                                       .collect(Collectors.toList());
        m.addAttribute("elencopaesi", paesiList);
        return "elencoBandiere";
    }
	
    @GetMapping("paese-random")
    public String getPaeseRandom(Model model, HttpSession session) {
    	
    	Utente utente = (Utente) session.getAttribute("utente"); // Retrieve the user from the session
        if (utente == null) {
            return "redirect:/login"; // Redirect to login if no user in session
        }
        model.addAttribute("utente", utente); // Pass the user to the view
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomCapitals = service.getCapitalRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomCapitals[correctPosition] = randomPaese.getCapitale();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("capitals", randomCapitals);
        return "Quiz";
    }
    
    @GetMapping("paese-random-senza")
    public String getPaeseRandom_2(Model model) {
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomCapitals = service.getCapitalRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomCapitals[correctPosition] = randomPaese.getCapitale();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("capitals", randomCapitals);
        return "Quiz-senza";
    }
    
    @GetMapping("paese-training")
    public String getPaeseRandom(Model model) {
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomCapitals = service.getCapitalRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomCapitals[correctPosition] = randomPaese.getCapitale();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("capitals", randomCapitals);
        return "training";
    }
   
    @GetMapping("paese-bandiere/regione/{regione}")
    public String getPaesiByRegioneView(@PathVariable String regione, Model m) {
        List<Paese> paesiList = service.getPaesiByRegione(regione);
        m.addAttribute("elencobandiere", paesiList);
        return "elencoBandiere";
    }
    
    @GetMapping("bandiera-random")
    public String getBandieraRandom(Model model, HttpSession session) {
    	
    	Utente utente = (Utente) session.getAttribute("utente"); // Retrieve the user from the session
        if (utente == null) {
            return "redirect:/login-flag"; // Redirect to login if no user in session
        }
        model.addAttribute("utente", utente); // Pass the user to the view
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomFlags = service.getFlagRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomFlags[correctPosition] = randomPaese.getBandiera();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("flags", randomFlags);
        return "quiz-bandiere";
    }
    
    @GetMapping("bandiera-training")
    public String getBandieraRandom(Model model) {
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomFlags = service.getFlagRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomFlags[correctPosition] = randomPaese.getBandiera();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("flags", randomFlags);
        return "training-bandiere";
    }
    
    @GetMapping("bandiera-random-senza")
    public String getBandieraRandom_2(Model model) {
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomFlags = service.getFlagRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomFlags[correctPosition] = randomPaese.getBandiera();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("flags", randomFlags);
        return "quiz-bandiera-senza";
    }
    
    @GetMapping("/memory")
    public String getMemoryBandierePage(Model model,  HttpSession session) {
    	Utente utente = (Utente) session.getAttribute("utente");
        if (utente == null) {
            return "redirect:/login-memory";
        }
        model.addAttribute("utente", utente);
        
        return "memory";
    }
    
    @GetMapping("memory-senza")
    public String getMemoryRandom_2(Model model) {
        
        Paese randomPaese = service.getPaeseRandom();
        String[] randomFlags = service.getFlagRandom(randomPaese.getId());
        
        // Include the correct capital in the random list at a random position
        Random rand = new Random();
        int correctPosition = rand.nextInt(4);
        randomFlags[correctPosition] = randomPaese.getBandiera();
        
        model.addAttribute("paese", randomPaese);
        model.addAttribute("flags", randomFlags);
        return "memory-senza";
    }
	
}