package com.aggeri.controllers;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aggeri.entities.Paese;
import com.aggeri.entities.Utente;
import com.aggeri.services.PaeseService;
import com.aggeri.services.UtenteService;
import com.aggeri.utils.RandomPaese;

@RestController
@RequestMapping("api")
public class PaeseREST {

	@Autowired
	PaeseService service;

	@Autowired
	UtenteService utenteService;

	RandomPaese random = new RandomPaese();

	@GetMapping("paese")
	List<Paese> getPaese() {
		return service.getPaese();
	}

	@GetMapping("paese/{id}")
	Paese getPaeseById(@PathVariable int id) {
		return service.getPaeseById(id);
	}

	@PostMapping("paese")
	Paese addPaese(@RequestBody Paese p) {
		return service.addPaese(p);
	}

	@PutMapping("paese")
	Paese updatePaese(@RequestBody Paese p) {
		return service.updatePaese(p);
	}

	@DeleteMapping("paese")
	ResponseEntity<Paese> deletePaese(@RequestBody Paese p) {
		service.deletePaese(p);
		return new ResponseEntity<>(null, HttpStatus.I_AM_A_TEAPOT);
	}

	@GetMapping("paese-random")
	String[] getCapitalRandom() {

		Integer[] numRand = new Integer[4];
		String[] capitali = new String[4];

		for (int i = 0; i < 4; i++) {
			int x = random.Random();

			if (x == numRand[i]) {
				do {
					x = random.Random();
				} while (x != numRand[i]);
			}
			capitali[i] = service.getPaeseById(x).getCapitale();
		}
		return capitali;
	}

	@GetMapping("paese-bandiere/regione/{regione}")
	public List<Paese> getPaesiByRegione(@PathVariable String regione) {
		return service.getPaese().stream().filter(p -> p.getRegione().equals(regione)).collect(Collectors.toList());
	}

	public Utente getUtenteById(String nome) {
		return utenteService.getUtenteById(nome);
	}

	@GetMapping("paese-bandiere/ordinate-asc/{ordine}")
	public List<Paese> getPaesiByOrdineAsc(@PathVariable String ordine) {

		return service.getPaesiByOrderAsc(ordine).stream().collect(Collectors.toList());
	}

	@GetMapping("paese-bandiere/ordinate-desc/{ordine}")
	public List<Paese> getPaesiByOrdineDesc(@PathVariable String ordine) {

		return service.getPaesiByOrderDesc(ordine).stream().collect(Collectors.toList());
	}

	@GetMapping("paese-bandiere/casuali/{numero}")
	public List<Paese> getPaesiByOrdineCasuale(@PathVariable int numero) {
		List<Paese> paesiOrdinati = service.getAllPaesi();

		Collections.shuffle(paesiOrdinati);

		return paesiOrdinati.stream().limit(numero).collect(Collectors.toList());

	}
	
    @GetMapping("/paesi")
    public List<Paese> getPaesi(@RequestParam(defaultValue = "6") int count) {
        List<Paese> allPaesi = service.getPaese();
        Collections.shuffle(allPaesi);
        return allPaesi.stream().limit(count).collect(Collectors.toList());
    }

}