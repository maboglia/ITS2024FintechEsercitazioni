package com.aggeri.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aggeri.entities.Utente;
import com.aggeri.services.UtenteService;

@RestController
@RequestMapping("/api")
public class UtenteREST {

    @Autowired
    private UtenteService utenteService;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
        boolean isAuthenticated = utenteService.authenticate(loginRequest.getUserName(), loginRequest.getPass());
        if (isAuthenticated) {
            return ResponseEntity.ok("Login successful!");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials!");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody Utente utente) {
        Utente registeredUser = utenteService.register(utente);
        if (registeredUser != null) {
            return ResponseEntity.ok("Registration successful!");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Registration failed!");
        }
    }

    public static class LoginRequest {
        private String userName;
        private String pass;

        // Getters and setters
        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getPass() {
            return pass;
        }

        public void setPass(String pass) {
            this.pass = pass;
        }
    }
    
    @GetMapping("/utente/all")
    public List<Utente> getAllUtenti(){
    		
    	List<Utente> utentiOrdinati = utenteService.getUtente();
		
		return utentiOrdinati
				.stream()
				.sorted((p1, p2) -> p2.getPunteggio() - p1.getPunteggio())
				.collect(Collectors.toList());
    	
    }
}