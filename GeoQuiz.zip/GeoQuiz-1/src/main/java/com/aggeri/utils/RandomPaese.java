package com.aggeri.utils;

import java.sql.SQLException;

import com.aggeri.repos.PaeseDAOImpl;

public class RandomPaese {
	
	public int Random() {
		
		PaeseDAOImpl dao = new PaeseDAOImpl();
		
		int numRand = 0;
		
		try {
			numRand = (int)(Math.random() * dao.getMax()) + 1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return numRand;
		
	}

}
