package com.aggeri.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aggeri.entities.Utente;
import com.aggeri.repos.UtenteDAO;

@Service
public class UtenteServiceImpl implements UtenteService {
	
	@Autowired
	private UtenteDAO dao;

	@Override
	public List<Utente> getUtente() {
		return dao.findAll();
	}

	@Override
	public Utente addUtente(Utente p) {
		return dao.save(p);
	}

	@Override
	public void updateUtente(Utente p) {
		dao.save(p);
	}

	@Override
	public void deleteUtente(Utente p) {
		dao.delete(p);

	}
	
	public boolean authenticate(String userName, String pass) {
		Optional<Utente> optionalUtente = dao.findByUserName(userName);
	        if (optionalUtente.isPresent()) {
	            Utente utente = optionalUtente.get();
	            return utente.getPass().equals(pass);
	        }
	        return false;
	    }

	public Utente register(Utente utente) {
		return dao.save(utente);
	}

	public Utente getUtenteById(String userName) {
	     return dao.findById(userName).orElse(null);
	}

	@Override
	public Optional<Utente> findByUsername(String name) {
		return dao.findById(name);
	}

}