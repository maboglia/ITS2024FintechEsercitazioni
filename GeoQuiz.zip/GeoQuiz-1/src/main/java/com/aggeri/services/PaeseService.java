package com.aggeri.services;

import java.util.List;

import com.aggeri.entities.Paese;

public interface PaeseService {

	List<Paese> getPaese();

	Paese getPaeseById(int id);

	Paese addPaese(Paese p);

	Paese updatePaese(Paese p);

	void deletePaese(Paese p);

	List<Paese> getPaesiByOrderAsc(String ordinamento);

	List<Paese> getPaesiByOrderDesc(String ordinamento);

	List<Paese> getAllPaesi();

	List<Paese> getPaesiByRegione(String regione);

	Paese getPaeseRandom();

	String[] getCapitalRandom(int id);

	String[] getFlagRandom(int id);

	List<Paese> getRandomPaesi(int count);

}
