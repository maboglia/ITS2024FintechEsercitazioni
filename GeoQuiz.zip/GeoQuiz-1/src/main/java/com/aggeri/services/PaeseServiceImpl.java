package com.aggeri.services;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.aggeri.entities.Paese;
import com.aggeri.repos.PaeseDAO;
import com.aggeri.utils.RandomPaese;

@Service
public class PaeseServiceImpl implements PaeseService {

	@Autowired
	private PaeseDAO dao;

	RandomPaese random = new RandomPaese();

	@Override
	public List<Paese> getPaese() {
		return dao.findAll();
	}

	@Override
	public Paese getPaeseById(int id) {
		return dao.findById(id).get();
	}

	@Override
	public Paese addPaese(Paese p) {
		return dao.save(p);
	}

	@Override
	public Paese updatePaese(Paese p) {
		return dao.save(p);
	}

	@Override
	public void deletePaese(Paese p) {
		dao.delete(p);
	}

	@Override
	public Paese getPaeseRandom() {
		return dao.getReferenceById(random.Random());
	}

	@Override
	public String[] getCapitalRandom(int excludeId) {
		String[] capitals = new String[4];
		int count = 0;

		while (count < 4) {
			int x = random.Random();
			Paese randomPaese = getPaeseById(x);
			if (randomPaese.getId() != excludeId && !Arrays.asList(capitals).contains(randomPaese.getCapitale())) {
				capitals[count++] = randomPaese.getCapitale();
			}
		}

		return capitals;
	}

	public List<Paese> getPaesiByRegione(String regione) {
		return dao.findByRegione(regione);
	}

	@Override
	public String[] getFlagRandom(int excludeId) {
		String[] flags = new String[4];
		int count = 0;

		while (count < 4) {
			int x = random.Random();
			Paese randomPaese = getPaeseById(x);
			if (randomPaese.getId() != excludeId && !Arrays.asList(flags).contains(randomPaese.getBandiera())) {
				flags[count++] = randomPaese.getBandiera();
			}
		}

		return flags;
	}

	@Override
	public List<Paese> getPaesiByOrderAsc(String ordinamento) {

		return dao.findAll(Sort.by(Sort.Direction.ASC, ordinamento));
	}

	@Override
	public List<Paese> getPaesiByOrderDesc(String ordinamento) {

		return dao.findAll(Sort.by(Sort.Direction.DESC, ordinamento));
	}

	@Override
	public List<Paese> getAllPaesi() {
		return dao.findAll();
	}
	
    public List<Paese> getRandomPaesi(int count) {
        List<Paese> allPaesi = dao.findAll();
        Collections.shuffle(allPaesi);
        return allPaesi.stream().limit(count).collect(Collectors.toList());
    }

}
