package com.aggeri.services;

import java.util.List;
import java.util.Optional;

import com.aggeri.entities.Utente;

public interface UtenteService {
	
	List<Utente> getUtente();
	Utente getUtenteById(String userName);
	Utente addUtente(Utente p);
	boolean authenticate(String userName, String pass);
	Utente register(Utente utente);
	void updateUtente(Utente utente);
	void deleteUtente(Utente p);
	Optional<Utente> findByUsername(String name);

}